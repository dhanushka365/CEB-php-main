<?php

class DataBaseConfig
{
    public $servername;
    public $username;
    public $password;
    public $databasename;

    public function __construct()
    {

        $this->servername = 'us-cdbr-east-02.cleardb.com';
        $this->username = 'b6ed9554515aee';
        $this->password = 'b68145f9';
        $this->databasename = 'heroku_07f03b5f61c9817';

    }
}

?>
