request_slowlog_timeout = 1

php_value[memory_limit] = <?=2*16?>M
